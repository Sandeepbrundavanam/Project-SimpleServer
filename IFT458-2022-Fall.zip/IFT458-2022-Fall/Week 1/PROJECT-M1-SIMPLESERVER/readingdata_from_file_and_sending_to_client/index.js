const httpServer = require('http');
const url = require('url');
const fs = require('fs');
/// Read data from file
//Template
const tempCourse = fs.readFileSync(
    `${__dirname}/data.txt`,
    'utf-8'
);
////////////////////////////////
//create server
const server = httpServer.createServer(function (req, res){//call back function
    const urlParameter = url.parse(req.url, true);
    console.log(urlParameter.query);
    console.log(urlParameter.pathname);
    if(urlParameter.query.id){//if there is query parameter named id
        //Courses page
        if(urlParameter.pathname === '/' || urlParameter.pathname.toLowerCase() == '/courses'){
            res.writeHead(200, {//Every thing ran successfully
                'content-type':'text/html'
            });
            res.end(`we recevived our first request from the client at resource ${urlParameter.pathname.toLowerCase()} with query parameter ${urlParameter.query.id}
            ${tempCourse}`)
        }
        else{
            res.writeHead(404, {//Server did not find what you were looking for
                'Content-type':'text/html'
            });
            res.end('resource not found')
        }
    }
});
//start listening to requests
server.listen(8000, 'localhost', function(){
    console.log(`listening to requests on port 8000`)
});