const httpServer = require('http');
const url = require('url');
const fs = require('fs');

const replaceTemplate = require('./replaceTemplate')
/// Read data from file
//Template
const tempCourse = fs.readFileSync(
    `${__dirname}/data.json`,
    'utf-8'
);
///////////////////////////
//Template
const templateHTMLCourse = fs.readFileSync(
    `${__dirname}/templateCourse.html`,
    'utf-8'
);
//function replaceTemplate(htmlstr, course){
   // let output = htmlstr.replace(/{%NAME}/g, course.courseName);
   // output = htmlstr.replace(/{%IMAGE}/g, course.courseimage);
   // output = htmlstr.replace(/{%FROM}/g, course.from);
    //output = htmlstr.replace(/{%INSTRUCTIONS}/g, course.instructions);
    //output = htmlstr.replace(/{%CREDITS}/g, course.credits);
    //output = htmlstr.replace(/{%DESCRIPTION}/g, course.description);
    //output = htmlstr.replace(/{%ID}/g, course.id);
    //return output;
//}
const dataObj = JSON.parse(tempCourse);//string to javascript object JSON
////////////////////////////////
//create server
const server = httpServer.createServer(function (req, res){//call back function
   // const urlParameter = url.parse(req.url, true);
    //console.log(urlParameter.query);
    //console.log(urlParameter.pathname);
    const {query,pathname} = url.parse(req.url, true);//object destructors

    if(query.id){//if there is query parameter named id
        //Courses page
        if(pathname === '/' || pathname.toLowerCase() == '/courses'){
            res.writeHead(200, {//Every thing ran successfully
                'content-type':'text/html'
            });
            const course = dataObj[Number(query.id)];//convert string to numeric values
            const strCourseName = JSON.stringify(course);
            const courseHTML = replaceTemplate(templateHTMLCourse, course);
           // res.end(`we recevived our first request from the client at resource ${urlParameter.pathname.toLowerCase()} with query parameter ${urlParameter.query.id}
          //  ${JSON.stringify(course)}//convert object back to string`)
          res.end(courseHTML);
        }
        else{
            res.writeHead(404, {//Server did not find what you were looking for
                'Content-type':'text/html'
            });
            res.end('resource not found')
        }
    }
});
//start listening to requests
server.listen(8000, 'localhost', function(){
    console.log(`listening to requests on port 8000`)
});