function add ( val1, val2){
    return val1+val2;
}

let result = add( 10, 100.5);

console.log(result);